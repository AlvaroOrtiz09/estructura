#pragma once
#include "Nodo.h"

class Pila {
		Nodo* inicio;//inicio es un puntero a un Nodo 
public:
		Pila() {
			inicio = NULL;
		}
		void push();
		void pop();
		void show();
		void top();
		void size();
	};