
#pragma once
#include <string>

using namespace std;

class Nodo
{
	public:
		int dato;
		string nombre;
		Nodo* sig;//Puntero a un nodo
	};

